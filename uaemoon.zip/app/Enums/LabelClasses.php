<?php

namespace App\Enums;

class LabelClasses{
    public static $classes = [
        'label-default',
        'label-primary',
        'label-secondary',
        'label-success',
        'label-warning',
        'label-danger',
    ];
}