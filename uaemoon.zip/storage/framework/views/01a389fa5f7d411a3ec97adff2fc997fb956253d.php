<?php $__env->startSection('title'); ?> <?php echo e(trans('user_actions.User_Actions')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">

            <h4 class="page-title"><?php echo e(trans('user_actions.User_Actions')); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('user_actions.User_Actions')); ?></a></li>
                <li class="breadcrumb-item active">Index</li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">All <?php echo e(trans('user_actions.User_Actions')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    Here you will find all the resources to make actions on them.
                </p>

                <table id="datatable" class="table table-striped table-responsive table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Created by</th>
                        <th>Updated by</th>
                        <th>Created at</th>
                        <th>Updated at</th>
                        <th>Control</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($resource->id); ?></td>
                            <td><?php echo e($resource->name); ?></td>
                            <td><?php echo e($resource->createdBy->name); ?></td>
                            <td><?php echo e($resource->updatedBy->name); ?></td>
                            <td><?php echo e($resource->created_at); ?></td>
                            <td><?php echo e($resource->updated_at); ?></td>
                            <td>






                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- end row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <!-- Create new -->
                <h4 class="m-t-0 header-title">Create new <?php echo e(trans('user_actions.User_Actions')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    Create new resource from here.
                </p>

                <?php echo $__env->make('permission_groups.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <!-- end card-box -->
        </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>