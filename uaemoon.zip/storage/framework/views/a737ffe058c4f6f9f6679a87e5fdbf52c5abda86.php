<?php $__env->startSection('title'); ?> <?php echo e($user->name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title"><?php echo e(trans('users.Edit_user')); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('users.Users')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('users.Edit')); ?></li>
            </ol>

        </div>
    </div>


    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <h4 class="header-title m-t-0"><?php echo e(trans('users.Edit_user_profile')); ?></h4>
                <p class="text-muted font-14 m-b-20">
                    <?php echo e(trans('users.Edit_and_update_on_resource_from_here')); ?>.
                </p>

                <form method="post" action="<?php echo e(route('users.update', $user->uuid)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="" for="email"><?php echo e(trans('users.Email_Or_Username')); ?></label>
                                <input type="text" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($user->email); ?>" required autofocus/>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="" for="name"><?php echo e(trans('users.Name')); ?></label>
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name); ?>" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="" for="phone"><?php echo e(trans('users.Phone')); ?></label>
                                <input id="phone" type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" value="<?php echo e($user->phone); ?>">

                                <?php if($errors->has('phone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>

                    <div class="form-group m-b-0">
                        <div>
                            <button type="submit" class="btn btn-success waves-effect waves-light">
                                <?php echo e(trans('users.Update_Data')); ?>

                            </button>
                        </div>
                    </div>
                </form>

                <hr>

                <div class="border border-danger p-2">
                    <form method="post" action="<?php echo e(route('users.update_password', $user->uuid)); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>


                        <label class="text-danger" for="password"><?php echo e(trans('users.Update_Password')); ?></label>

                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <input type="password" placeholder="<?php echo e(trans('users.Enter_new_password')); ?> .." id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"/>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-block btn-danger waves-effect waves-light">
                                    <?php echo e(trans('users.Update_Password')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
        <!-- end card-box -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>