<?php $__env->startSection('content'); ?>
    <!-- start page-title -->
    <section class="page-title">
        <div class="page-title-container">
            <div class="page-title-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col col-xs-12">
                            <h2><?php echo e(trans('website.my_profile')); ?></h2>
                            <ol class="breadcrumb">
                                <li><a href="<?php echo e(url('/')); ?>"><?php echo e(trans('website.home')); ?></a></li>
                                <li><?php echo e(trans('website.my_profile')); ?></li>
                            </ol>
                        </div>
                    </div> <!-- end row -->
                </div> <!-- end container -->
            </div>
        </div>
    </section>
    <!-- end page-title -->

    <!-- start home-pg-prodcut-section -->
    <section class="home-pg-prodcut-section section-padding">
        <div class="container-1410">
            <div class="row">
                <div class="col-xs-12">
                    <!-- Nav tabs -->
                    <div class="tablinks">
                        <ul>
                            <li class="active">
                                <a href="#tab-1" data-toggle="tab"><?php echo e(trans('website.my_profile')); ?></a>
                            </li>
                            <li>
                                <a href="#tab-2" data-toggle="tab"><?php echo e(trans('website.my_advertises')); ?></a>
                            </li>
                        </ul>
                    </div>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div class="tab-pane in active" id="tab-1">
                            <div class="col-md-12" style="padding-top: 50px;">
                                <form action="<?php echo e(route('front.user.update_profile')); ?>" method="post"
                                      enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="woocommerce-billing-fields">

                                        <h3><?php echo e(trans('website.update_profile')); ?></h3>

                                        <p class="form-row col-md-6">
                                            <label for="name" class=""><?php echo e(trans('website.name')); ?> <abbr
                                                    class="required" title="required">*</abbr></label>
                                            <input required id="name" type="text"
                                                   class="input-text <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                   name="name"
                                                   autocomplete="off" value="<?php echo e($user['name']); ?>"/>
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" style="color: red;" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </p>

                                        <p class="form-row col-md-6">
                                            <label for="phone" class=""><?php echo e(trans('website.phone')); ?> <abbr
                                                    class="required" title="required">*</abbr></label>
                                            <input required id="phone" type="text"
                                                   class="input-text <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>"
                                                   name="phone"
                                                   autocomplete="off" value="<?php echo e($user['phone']); ?>"/>
                                            <?php if($errors->has('phone')): ?>
                                                <span class="invalid-feedback" style="color: red;" role="alert">
                                                <strong><?php echo e($errors->first('phone')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </p>
                                        <p class="form-row col-md-12">
                                            <button type="submit"
                                                    class="woocommerce-button button woocommerce-form-login__submit"><?php echo e(trans('website.update')); ?>

                                            </button>
                                        </p>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-12" style="padding-top: 100px;">
                                <form action="<?php echo e(route('front.user.change_password')); ?>" method="post"
                                      enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="woocommerce-billing-fields">

                                        <h3><?php echo e(trans('website.change_password')); ?></h3>

                                        <p class="form-row col-md-6">
                                            <label for="current_password" class=""><?php echo e(trans('website.current_password')); ?>

                                                <abbr
                                                    class="required" title="required">*</abbr></label>
                                            <input required id="current_password" type="password"
                                                   class="input-text <?php echo e($errors->has('current_password') ? ' is-invalid' : ''); ?>"
                                                   name="current_password"
                                                   autocomplete="off"/>
                                            <?php if($errors->has('current_password')): ?>
                                                <span class="invalid-feedback" style="color: red;" role="alert">
                                                <strong><?php echo e($errors->first('current_password')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </p>
                                        <div class="clearfix"></div>

                                        <p class="form-row col-md-6">
                                            <label for="new_password" class=""><?php echo e(trans('website.new_password')); ?> <abbr
                                                    class="required" title="required">*</abbr></label>
                                            <input required id="new_password" type="password"
                                                   class="input-text <?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>"
                                                   name="new_password"
                                                   autocomplete="off"/>
                                            <?php if($errors->has('new_password')): ?>
                                                <span class="invalid-feedback" style="color: red;" role="alert">
                                                <strong><?php echo e($errors->first('new_password')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </p>

                                        <p class="form-row col-md-6">
                                            <label for="new_confirm_password"
                                                   class=""><?php echo e(trans('website.new_confirm_password')); ?> <abbr
                                                    class="required" title="required">*</abbr></label>
                                            <input required id="new_confirm_password" type="password"
                                                   class="input-text <?php echo e($errors->has('new_confirm_password') ? ' is-invalid' : ''); ?>"
                                                   name="new_confirm_password"
                                                   autocomplete="off"/>
                                            <?php if($errors->has('new_confirm_password')): ?>
                                                <span class="invalid-feedback" style="color: red;" role="alert">
                                                <strong><?php echo e($errors->first('new_confirm_password')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </p>
                                        <p class="form-row col-md-12">
                                            <button type="submit"
                                                    class="woocommerce-button button woocommerce-form-login__submit"><?php echo e(trans('website.update')); ?>

                                            </button>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="tab-pane fade woocommerce-cart" id="tab-2">
                            <div class="col col-xs-12">
                                <div class="woocommerce" style="padding-top: 50px;">
                                    <table class="shop_table shop_table_responsive cart">
                                        <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Title</th>
                                            <th>Cover</th>
                                            <th>Status</th>
                                            <th>Status At</th>
                                            <th>Is VIP</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(!$resources->isEmpty()): ?>
                                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="cart_item">
                                                    <td><?php echo e(isset($resource->category->name) ? getFromJson($resource->category->name , lang()) : '-'); ?></td>
                                                    <td><?php echo e(lang() == 'ar' ? $resource->title_ar : $resource->title_en); ?></td>
                                                    <td>
                                                        <div style="width:50px;height: 50px;overflow: hidden">
                                                            <img style="width:100%;" src="<?php echo e(url($resource->cover)); ?>"
                                                                 alt="">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php if($resource->status == 0): ?>
                                                            <span class="badge" style="background-color: orange;">Pending</span>
                                                        <?php elseif($resource->status == 1): ?>
                                                            <span class="badge" style="background-color: green;">Approved</span>
                                                        <?php elseif($resource->status == 2): ?>
                                                            <span class="badge" style="background-color: red;">Not Approved</span>
                                                        <?php elseif($resource->status == 3): ?>
                                                            <span class="badge"
                                                                  style="background-color: red;">Expired</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($resource->status == 0): ?>
                                                            <span
                                                                class="badge">Created At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->created_at))); ?></span>
                                                        <?php elseif($resource->status == 1): ?>
                                                            <span
                                                                class="badge">Approved At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->approved_at))); ?></span>
                                                        <?php elseif($resource->status == 2): ?>
                                                            <span
                                                                class="badge">Not Approved At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->not_approved_at))); ?></span>
                                                        <?php elseif($resource->status == 3): ?>
                                                            <span
                                                                class="badge">Expired At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->expired_at))); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($resource->is_featured == 0): ?>
                                                            <span class="badge"
                                                                  style="background-color: orange;">NO</span>
                                                        <?php elseif($resource->is_featured == 1): ?>
                                                            <span class="badge"
                                                                  style="background-color: green;">YES</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="10" class="text-center">
                                                    <?php echo e(trans('website.you_dont_have_advertises_yet')); ?>

                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end tab-content -->
                </div>
            </div>
        </div>
    </section>
    <!-- end home-pg-prodcut-section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>