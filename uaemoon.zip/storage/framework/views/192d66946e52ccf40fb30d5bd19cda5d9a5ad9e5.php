<?php $__env->startSection('title'); ?> <?php echo e(trans('users.Users')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">

            <h4 class="page-title"><?php echo e(trans('users.Users')); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('users.Users')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('users.Index')); ?></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-tabs navtab-bg nav-justified">
                <li class="nav-item">
                    <a href="#searchResource" data-toggle="tab" aria-expanded="false" class="nav-link active"><?php echo e(trans('users.Search_and_filter')); ?></a>
                </li>
                <li class="nav-item">
                    <a href="#createResource" data-toggle="tab" aria-expanded="true" class="nav-link"><?php echo e(trans('users.Create_new')); ?></a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="searchResource">
                    <h4 class="header-title m-t-0">Search all users</h4>
                    <p class="text-muted font-14 m-b-20">
                        <?php echo e(trans('users.Search_on_resource_from_here')); ?>.
                    </p>

                    <?php echo $__env->make('users.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>
                <div class="tab-pane" id="createResource">
                    <h4 class="m-t-0 header-title"><?php echo e(trans('users.Create_new_user')); ?></h4>
                    <p class="text-muted font-14 m-b-30">
                        <?php echo e(trans('users.Create_new_resource_from_here')); ?>.
                    </p>

                    <?php echo $__env->make('users.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <!-- end card-box -->
    </div>

    
    
        
            
                
                
                
                    
                

                
            
        
        
        
    


    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <div class="container-fluid">
                    <h4 class="m-t-0 header-title"><?php echo e(trans('users.All_Users')); ?></h4>
                    <p class="text-muted font-14 m-b-30">
                        <?php echo e(trans('users.Here_you_will_find_all_the_resources_to_make_actions_on_them')); ?>.
                    </p>
                </div>

                <table data-page-length='50' id="datatable-users-buttons" class="table table-responsive table-striped table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('users.Id')); ?></th>
                            <th><?php echo e(trans('users.Name')); ?></th>
                            <th><?php echo e(trans('users.Users_Groups')); ?></th>
                            <th><?php echo e(trans('users.Created_by')); ?></th>
                            <th><?php echo e(trans('users.Updated_by')); ?></th>
                            <th><?php echo e(trans('users.Created_at')); ?></th>
                            <th><?php echo e(trans('users.Updated_at')); ?></th>
                            <th><?php echo e(trans('users.Control')); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($resource->id); ?></td>
                                <td><?php echo e($resource->name); ?></td>
                                <td>
                                    <?php $__currentLoopData = $resource->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="label <?php echo e($role->class); ?>"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e(($resource->createdBy)? $resource->createdBy->name : '-'); ?></td>
                                <td><?php echo e(($resource->updatedBy)? $resource->updatedBy->name : '-'); ?></td>
                                <td><?php echo e($resource->created_at); ?></td>
                                <td><?php echo e($resource->updated_at); ?></td>
                                <td>
                                    <?php if(check_authority('edit.users')): ?>
                                        <a href="<?php echo e(route('users.edit', [$resource->uuid])); ?>" class="update-modal btn btn-sm btn-success" title="<?php echo e(trans('users.Update_user')); ?>">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    <?php endif; ?>

                                    <?php if(check_authority('delete.users')): ?>
                                    <a href="<?php echo e(route('users.destroy', [$resource->uuid])); ?>" class="confirm-delete btn btn-sm btn-danger" title="<?php echo e(trans('users.Delete_user')); ?>">
                                        <i class="fa fa-times"></i>
                                    </a>
                                    <?php endif; ?>

                                    <?php if(check_authority('edit.users')): ?>
                                    <a href="<?php echo e(route('users.reset_password', [$resource->uuid])); ?>" class="btn btn-sm btn-warning" title="<?php echo e(trans('users.Reset_password')); ?>">
                                        <i class="fa fa-recycle"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var tableDTUsers = $('#datatable-users-buttons').DataTable({
                lengthChange: false,
                buttons: [
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6]
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6]
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6]
                        }
                    },
                    {
                        extend: 'print',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6]
                        }
                    }
                ],
            });
        tableDTUsers.buttons().container().appendTo('#datatable-users-buttons_wrapper .col-md-6:eq(0)');

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>