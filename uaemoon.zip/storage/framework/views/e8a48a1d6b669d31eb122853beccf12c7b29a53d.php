<?php $__env->startSection('page_title'); ?> <?php echo e(trans('login.Login')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="wrapper-page">
        <div class="card-box">
            <div class="panel-heading">



                <h4 class="text-center">
                    <?php echo e(trans('login.Login_to')); ?> <strong><?php echo e(config('app.name')); ?></strong>
                </h4>
            </div>

            <div class="p-20">
                <form class="form-horizontal" method="post" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="control-label" for="email"><?php echo e(trans('login.Username')); ?></label><i class="bar"></i>
                        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"/>

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="user-password"><?php echo e(trans('login.Password')); ?></label><i class="bar"></i>
                        <input id="password" type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required/>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    
                    
                    
                    
                    
                    
                    
                    

                    <div class="form-group text-center m-t-20">
                        <button class="btn btn-purple btn-block text-uppercase waves-effect waves-light" type="submit">
                            <?php echo e(trans('login.login')); ?>

                        </button>
                    </div>

                    
                    
                    
                    
                    

                    
                    
                    
                    
                    

                    
                    
                    
                    
                    

                    
                    
                    

                    
                    
                    
                    
                    
                </form>

            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <p class="">

                </p>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth._layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>