<form method="post" action="<?php echo e(route('users.update', $resource->uuid)); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="" for="email"><?php echo e(trans('users.Email')); ?></label>
                <input type="email" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($resource->email); ?>" required autofocus/>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="" for="name"><?php echo e(trans('users.Username')); ?></label>
                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($resource->name); ?>" required>

                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">

            <div class="form-group">
                <label class="" for="phone"><?php echo e(trans('users.Phone')); ?></label>
                <input id="phone" type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" value="<?php echo e($resource->phone); ?>" required>

                <?php if($errors->has('phone')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="" for="password"><?php echo e(trans('users.Password')); ?></label><i class="bar"></i>
                <input type="password" id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"/>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label><?php echo e(trans('users.Users_Groups')); ?> <span data-select2-target="roles_update" class="select-all text-success btn-link">(<?php echo e(trans('users.Select_All')); ?>)</span></label>
        <select name="roles[]" id="roles_update" class="select2 select2-multiple" multiple="" data-placeholder="Choose ..." tabindex="-1" aria-hidden="true" required>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(in_array($role->id, $resource->roles->pluck('id')->toArray())): ?> selected <?php endif; ?> value="<?php echo e($role->uuid); ?>"><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group m-b-0">
        <div>
            <button type="submit" class="btn btn-success waves-effect waves-light">
                <i class="fa fa-fe fa-edit"></i> <?php echo e(trans('users.Update')); ?>

            </button>
        </div>
    </div>
</form>

<hr>

<div class="border border-danger p-2">
    <form method="post" action="<?php echo e(route('users.update_password', $resource->uuid)); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>


        <label class="text-danger" for="password"><?php echo e(trans('users.Update_Password')); ?></label>

        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <input type="password" placeholder="Enter new password .." id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"/>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-block btn-danger waves-effect waves-light">
                    <i class="fa fa-fe fa-edit"></i> <?php echo e(trans('users.Update_User_Password')); ?>

                </button>
            </div>
        </div>
    </form>
</div>

