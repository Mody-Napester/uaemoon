<?php $__env->startSection('title'); ?>
    - General Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('settings.general_settings')); ?></li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo e(Form::open(array('files' => true))); ?>

                <div class="row">
                    <div class="form-group col-md-4">
                        <label>Website Language</label>
                        <select required name="site_lang" class="form-control select2">
                            <option value="">Choose</option>
                            <option <?php if($settings['site_lang'] == 1): ?> selected <?php endif; ?> value="1">Arabic</option>
                            <option <?php if($settings['site_lang'] == 2): ?> selected <?php endif; ?> value="2">English</option>
                            <option <?php if($settings['site_lang'] == 3): ?> selected <?php endif; ?> value="3">Both</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Website Title [AR]</label>
                        <input required type="text"
                               value="<?php echo e($settings['title_ar']); ?>"
                               name="title_ar"
                               class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Website Title [EN]</label>
                        <input required type="text"
                               value="<?php echo e($settings['title_en']); ?>"
                               name="title_en"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-6">
                        <label>Logo [AR]</label>
                        <input type="file"
                               value="<?php echo e($settings['logo_ar']); ?>"
                               name="logo_ar"
                               class="form-control">
                        <small>Recommended dimension 180x70</small>
                        <br>
                        <?php if(!empty($settings['logo_ar'])): ?>
                            <img src="<?php echo e(asset('public/images/settings/' .$settings['logo_ar'])); ?>" width="100"
                                 height="100">
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Logo [EN]</label>
                        <input type="file"
                               value="<?php echo e($settings['logo_en']); ?>"
                               name="logo_en"
                               class="form-control">
                        <small>Recommended dimension 180x70</small>
                        <br>
                        <?php if(!empty($settings['logo_en'])): ?>
                            <img src="<?php echo e(asset('public/images/settings/' .$settings['logo_en'])); ?>" width="100"
                                 height="100">
                        <?php endif; ?>
                    </div>

                    <div class="form-group col-md-4">
                        <label>Mobile</label>
                        <input required type="text"
                               value="<?php echo e($settings['mobile']); ?>"
                               name="mobile"
                               class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Phone</label>
                        <input type="text"
                               value="<?php echo e($settings['phone']); ?>"
                               name="phone"
                               class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>WhatsApp</label>
                        <input type="text"
                               value="<?php echo e($settings['whatsapp']); ?>"
                               name="whatsapp"
                               class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Email</label>
                        <input required type="email"
                               value="<?php echo e($settings['email']); ?>"
                               name="email"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label>Website URL</label>
                        <input type="text"
                               value="<?php echo e($settings['website']); ?>"
                               name="website"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label>Address [AR]</label>
                        <input type="text"
                               value="<?php echo e($settings['address_ar']); ?>"
                               name="address_ar"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label>Address [EN]</label>
                        <input type="text"
                               value="<?php echo e($settings['address_en']); ?>"
                               name="address_en"
                               class="form-control">
                    </div>
                    <div class="form-group col-md-12">
                        <button class="btn btn-sm btn-info" type="submit">Save</button>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>