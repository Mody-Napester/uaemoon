<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>

                <?php if(check_authority('use.security')): ?>

                    <li class="text-muted menu-title"><?php echo e(trans('sidebar.Security')); ?></li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ti-home"></i>
                            <span> <?php echo e(trans('sidebar.Permission_Control_System')); ?> </span> <span
                                class="menu-arrow"></span></a>
                        <ul class="list-unstyled">

                            <?php if(in_array(auth()->user()->id, config('vars.authorized_users'))): ?>
                                <li><a href="<?php echo e(route('permission-groups.index')); ?>"
                                       class="fire-loader-anchor"><?php echo e(trans('sidebar.User_Actions')); ?></a></li>
                                <li><a href="<?php echo e(route('permissions.index')); ?>"
                                       class="fire-loader-anchor"><?php echo e(trans('sidebar.Data_Entry_Screens')); ?></a></li>
                            <?php endif; ?>

                            <?php if(check_authority('list.user_groups')): ?>
                                <li><a href="<?php echo e(route('roles.index')); ?>"
                                       class="fire-loader-anchor"><?php echo e(trans('sidebar.Users_Groups')); ?></a></li>
                            <?php endif; ?>

                            <?php if(check_authority('list.users')): ?>
                                <li><a href="<?php echo e(route('users.index')); ?>"
                                       class="fire-loader-anchor"><?php echo e(trans('sidebar.Users')); ?></a></li>
                            <?php endif; ?>
                        </ul>
                    </li>

                <?php endif; ?>

                <?php if(check_authority('use.settings')): ?>
                    <li class="text-muted menu-title"><?php echo e(trans('sidebar.Settings')); ?></li>

                    <?php if(check_authority('list.settings')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(route('editSettings')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-settings"></i> <span> <?php echo e(trans('sidebar.general_settings')); ?> </span></a>
                        </li>
                    <?php endif; ?>
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ti-home"></i>
                            <span> <?php echo e(trans('sidebar.home_page')); ?> </span> <span
                                class="menu-arrow"></span></a>
                        <ul class="list-unstyled">

                            <?php if(check_authority('list.home_seo')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('editSettingsHomeSeo')); ?>"
                                       class="waves-effect fire-loader-anchor"><i
                                            class="ti-agenda"></i>
                                        <span> <?php echo e(trans('sidebar.home_page_seo')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                            <?php if(check_authority('list.slider')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('listSlider')); ?>" class="waves-effect fire-loader-anchor"><i
                                            class="ti-image"></i> <span> <?php echo e(trans('sidebar.slider')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php if(check_authority('list.social')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(route('social.index')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-medall-alt"></i> <span> <?php echo e(trans('sidebar.Socials')); ?> </span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(check_authority('list.lookups')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(route('lookup.index')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-user"></i> <span> <?php echo e(trans('sidebar.Lookups')); ?> </span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(check_authority('list.translations')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(url('translations')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-flag"></i> <span> <?php echo e(trans('sidebar.Translations')); ?> </span></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(check_authority('use.resources')): ?>
                    <li class="text-muted menu-title"><?php echo e(trans('sidebar.Resources')); ?></li>
                    <?php if(check_authority('list.category')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(route('category.index')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-clip"></i> <span> <?php echo e(trans('sidebar.Categories')); ?> </span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(check_authority('list.page')): ?>
                        <li class="has_sub">
                            <a href="<?php echo e(route('page.index')); ?>" class="waves-effect fire-loader-anchor"><i
                                    class="ti-pencil-alt"></i> <span> <?php echo e(trans('sidebar.Pages')); ?> </span></a>
                        </li>
                    <?php endif; ?>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ti-clipboard"></i>
                            <span> <?php echo e(trans('sidebar.about_us')); ?> </span> <span
                                class="menu-arrow"></span></a>
                        <ul class="list-unstyled">

                            <?php if(check_authority('list.about_us_seo')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('editSettingsAboutSeo')); ?>"
                                       class="waves-effect fire-loader-anchor"><i
                                            class="ti-agenda"></i>
                                        <span> <?php echo e(trans('sidebar.about_us_seo')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                            <?php if(check_authority('list.about_us')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('editSettingsAboutUs')); ?>"
                                       class="waves-effect fire-loader-anchor"><i
                                            class="ti-pin-alt"></i> <span> <?php echo e(trans('sidebar.about_us')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="ti-clipboard"></i>
                            <span> <?php echo e(trans('sidebar.contact_us')); ?> </span> <span
                                class="menu-arrow"></span></a>
                        <ul class="list-unstyled">

                            <?php if(check_authority('list.contact_us_seo')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('editSettingsContactSeo')); ?>"
                                       class="waves-effect fire-loader-anchor"><i
                                            class="ti-agenda"></i>
                                        <span> <?php echo e(trans('sidebar.contact_us_seo')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                            <?php if(check_authority('list.contact_us')): ?>
                                <li class="has_sub">
                                    <a href="<?php echo e(route('editSettingsContactUs')); ?>"
                                       class="waves-effect fire-loader-anchor"><i
                                            class="ti-pin-alt"></i> <span> <?php echo e(trans('sidebar.contact_us')); ?> </span></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                    <?php if(check_authority('use.website')): ?>
                        <li class="text-muted menu-title"><?php echo e(trans('sidebar.website')); ?></li>

                        <?php if(check_authority('list.advertise')): ?>
                            <li class="has_sub">
                                <a href="<?php echo e(route('advertise.list')); ?>" class="waves-effect fire-loader-anchor"><i
                                        class="ti-agenda"></i> <span> <?php echo e(trans('sidebar.advertises')); ?> </span></a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>

            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
