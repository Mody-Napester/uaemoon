<?php $__env->startSection('title'); ?> <?php echo e(trans('users_groups.Users_Groups')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">

            <h4 class="page-title"><?php echo e(trans('users_groups.Users_Groups')); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('users_groups.Users_Groups')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('users_groups.Index')); ?></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title"><?php echo e(trans('users_groups.All_Users_Groups')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    <?php echo e(trans('users_groups.Here_you_will_find_all_the_resources_to_make_actions_on_them')); ?>.
                </p>

                <table id="datatable" class="table table-responsive table-striped table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th><?php echo e(trans('users_groups.Id')); ?></th>
                        <th><?php echo e(trans('users_groups.Name')); ?></th>
                        <th><?php echo e(trans('users_groups.Permissions')); ?></th>
                        <th><?php echo e(trans('users_groups.Created_by')); ?></th>
                        <th><?php echo e(trans('users_groups.Updated_by')); ?></th>
                        <th><?php echo e(trans('users_groups.Created_at')); ?></th>
                        <th><?php echo e(trans('users_groups.Updated_at')); ?></th>
                        <th><?php echo e(trans('users_groups.Control')); ?></th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($resource->id); ?></td>
                            <td>
                                <span class="label <?php echo e($resource->class); ?>"><?php echo e($resource->name); ?></span>
                            </td>
                            <td>
                                <?php $__currentLoopData = $resource->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span style="color: #333;border: 1px solid #333;display: inline-block" class="label m-b-5"><?php echo e(str_well(\App\PermissionGroup::getBy('id', $permission->pivot->permission_group_id)->name)); ?> <?php echo e(str_well($permission->name)); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($resource->createdBy->name); ?></td>
                            <td><?php echo e($resource->updatedBy->name); ?></td>
                            <td><?php echo e($resource->created_at); ?></td>
                            <td><?php echo e($resource->updated_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('roles.edit', [$resource->uuid])); ?>" class="update-modal btn btn-sm btn-success">
                                    <i class="fa fa-edit"></i>
                                </a>



                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- end row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <!-- Create new -->
                <h4 class="m-t-0 header-title"> <?php echo e(trans('users_groups.Create_new_Users_Group')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    <?php echo e(trans('users_groups.Create_new_resource_from_here')); ?>.
                </p>

                <?php echo $__env->make('roles.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <!-- end card-box -->
        </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>