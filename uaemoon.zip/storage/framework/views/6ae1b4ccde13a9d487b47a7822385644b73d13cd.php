<?php
    $pagesFooter = \App\Page::getAll([
        'is_active' => 1,
        'in_footer' => 1,
        'is_privacy_page' => 0,
        'is_terms_page' => 0,
    ]);
    $pagesHeader = \App\Page::getAll([
        'is_active' => 1,
        'in_menu' => 1,
        'is_privacy_page' => 0,
        'is_terms_page' => 0,
    ]);
    $privacyPage = \App\Page::getAll([
        'is_active' => 1,
        'is_privacy_page' => 1,
        'getFirst' => true
    ]);

    $termsPage = \App\Page::getAll([
        'is_active' => 1,
        'is_terms_page' => 1,
        'getFirst' => true
    ]);
    $settings = \App\Settings::getById(1);
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="irstheme">

    <title> <?php if(lang() == 'ar'): ?> <?php echo e($settings['title_ar']); ?> <?php else: ?> <?php echo e($settings['title_en']); ?> <?php endif; ?> <?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(url('assets/front/assets/css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/icomoon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/owl.theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/swiper.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/owl.transitions.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/jquery.fancybox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/front/assets/css/jquery-ui.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(url('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('assets/css/alerts.css')); ?>" rel="stylesheet" type="text/css"/>

    <link href="<?php echo e(url('assets/front/assets/css/style.css')); ?>" rel="stylesheet">
    <?php if(lang() == 'ar'): ?>
        
        <link href="<?php echo e(url('assets/front/assets/css/bootstrap.rtl.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('assets/front/assets/css/style-rtl.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js') }}"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js') }}"></script>
    <![endif]-->
    <style>
        .is-invalid {
            border: 1px solid red !important;
        }

        .custom-select {
            border-radius: 0;
            height: 50px;
        }
    </style>
    <?php echo $__env->yieldContent('header'); ?>
</head>

<body>

<!-- start page-wrapper -->
<div class="page-wrapper">

    <div class="body-overlay"></div>

    <!-- start preloader -->
    <div class="preloader">
        <div class="sk-chase">
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
        </div>
    </div>
    <!-- end preloader -->

    <!-- Start header -->
    <header id="header" class="site-header header-style-1">

        <nav class="navigation navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="open-btn">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php if(lang() == 'ar'): ?>
                            <img src="<?php echo e(url('public/images/settings/' . $settings['logo_ar'])); ?> " alt="Logo">
                        <?php else: ?>
                            <img src="<?php echo e(url('public/images/settings/' . $settings['logo_en'])); ?> " alt="Logo">
                        <?php endif; ?>

                    </a>
                </div>
                <div class="header-left">
                    <div class="side-info-bars">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="side-info-content">
                        <button class="btn side-info-close-btn"><i class="ti-close"></i></button>
                        <div class="logo">
                            <?php if(lang() == 'ar'): ?>
                                <img src="<?php echo e(url('public/images/settings/' . $settings['logo_ar'])); ?> " alt="Logo">
                            <?php else: ?>
                                <img src="<?php echo e(url('public/images/settings/' . $settings['logo_en'])); ?> " alt="Logo">
                            <?php endif; ?>
                        </div>
                        <div class="text">
                            <p><?php echo e($settings['address_' . lang()]); ?></p>
                            <ul class="info">
                                <li><?php echo e(trans('website.contact_us')); ?>: <?php echo e($settings['mobile']); ?></li>
                                <li><?php echo e(trans('website.mail_us')); ?>: <?php echo e($settings['email']); ?></li>
                            </ul>
                            <ul class="social-links">
                                <?php
                                    $facebook = \App\Provider::getByName('facebook');
                                    $twitter = \App\Provider::getByName('twitter');
                                    $instagram = \App\Provider::getByName('instagram');
                                    $pinterest = \App\Provider::getByName('pinterest');
                                ?>
                                <?php if($facebook && isset($facebook->social[0]->link)): ?>
                                    <li><a target="_blank" href="<?php echo e($facebook->social[0]->link); ?>"><i
                                                class="ti-facebook"></i></a></li>
                                <?php endif; ?>
                                <?php if($twitter && isset($twitter->social[0]->link)): ?>
                                    <li><a target="_blank" href="<?php echo e($twitter->social[0]->link); ?>"><i
                                                class="ti-twitter-alt"></i></a></li>
                                <?php endif; ?>
                                <?php if($instagram && isset($instagram->social[0]->link)): ?>
                                    <li><a target="_blank" href="<?php echo e($instagram->social[0]->link); ?>"><i
                                                class="ti-instagram"></i></a></li>
                                <?php endif; ?>
                                <?php if($pinterest && isset($pinterest->social[0]->link)): ?>
                                    <li><a target="_blank" href="<?php echo e($pinterest->social[0]->link); ?>"><i
                                                class="ti-pinterest"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
                <div id="navbar" class="navbar-collapse collapse navigation-holder">
                    <button class="close-navbar"><i class="ti-close"></i></button>
                    <ul class="nav navbar-nav">
                        
                        
                        
                        
                        
                        
                        
                        
                        <li><a href="<?php echo e(url('/')); ?>"><?php echo e(trans('website.home')); ?></a></li>
                        <li><a href="<?php echo e(route('front.page.aboutUs')); ?>"><?php echo e(trans('website.about_us')); ?></a></li>
                        <li><a href="<?php echo e(route('front.page.contactUs')); ?>"><?php echo e(trans('website.contact_us')); ?></a></li>
                        <?php $__currentLoopData = $pagesHeader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('front.page.anyPage', $val->uuid)); ?>"><?php echo getFromJson($val->name , lang()); ?> </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="menu-item-has-children">
                            <a>
                                <?php echo e(trans('website.language')); ?>

                                
                            </a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('language', 'ar')); ?>"><?php echo e(trans('website.arabic')); ?></a></li>
                                <li><a href="<?php echo e(route('language', 'en')); ?>"><?php echo e(trans('website.english')); ?></a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!-- end of nav-collapse -->
                <div class="header-right">
                    <?php if(Auth::user()): ?>
                        <?php
                            $user = Auth::user()
                        ?>
                        <div class="my-account-link">
                            <a title="<?php echo e('(' . $user->name . ') ' . trans('website.profile')); ?>"
                               href="<?php echo e(route('front.user.profile')); ?>"> <i class="fa fa-user-circle"></i></a>
                        </div>
                        <div class="my-account-link">
                            <a title="<?php echo e(trans('website.add_new_advertise')); ?>" href="<?php echo e(route('front.advertise.add')); ?>">
                                <i
                                    class="fa fa-plus"></i></a>
                        </div>
                        <div class="my-account-link">
                            <a title="<?php echo e(trans('website.logout')); ?>" href="<?php echo e(route('front.user.getLogout')); ?>"> <i
                                    class="fa fa-sign-out"></i></a>
                        </div>
                    <?php else: ?>
                        <div class="my-account-link">
                            <a title="<?php echo e(trans('website.login_or_register')); ?>"
                               href="<?php echo e(route('front.user.login_or_register')); ?>"><i class="fa fa-user-circle"></i></a>
                        </div>
                    <?php endif; ?>

                </div>
            </div><!-- end of container -->
        </nav>
    </header>
    <!-- end of header -->

    <?php if(session('message')): ?>
        <div class="float-alert">
            <div class="row alert-div alert alert-<?php echo e(session('message')['type']); ?> clearfix">
                <div class="col-md-10 p-0 m-0"><?php echo e(session('message')['text']); ?></div>
                <div class="col-md-2 p-0 m-0 text-right">
                    <i class="alert-close fa fa-fw fa-close"></i>
                </div>
            </div>
        </div>
<?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>

<!-- start site-footer -->
    <footer class="site-footer">
        <div class="container-1410">
            <div class="row widget-area">
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <div class="col-lg-5 col-xs-6 widget-col">
                    <div class="widget contact-widget">
                        <h3><?php echo e(trans('website.contact_info')); ?></h3>
                        <ul>
                            <li><?php echo e(trans('website.contact_us')); ?>: <?php echo e($settings['mobile']); ?></li>
                            <li><?php echo e(trans('website.mail_us')); ?>: <?php echo e($settings['email']); ?></li>
                            <li><?php echo e(trans('website.address')); ?>: <?php echo e($settings['address_' . lang()]); ?></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-xs-6 widget-col">
                    <div class="widget company-widget">
                        <h3><?php echo e(trans('website.our_company')); ?></h3>
                        <ul>
                            <li><a href="<?php echo e(route('front.page.aboutUs')); ?>"><?php echo e(trans('website.about_us')); ?></a></li>
                            <li><a href="<?php echo e(route('front.page.contactUs')); ?>"><?php echo e(trans('website.contact_us')); ?></a></li>
                            <?php if($privacyPage): ?>
                                <li><a href="<?php echo e(route('front.page.privacyPage')); ?>"><?php echo e(trans('website.privacy_page')); ?> </a>
                                </li>
                            <?php endif; ?>
                            <?php if($termsPage): ?>
                                <li><a href="<?php echo e(route('front.page.termsPage')); ?>"><?php echo e(trans('website.terms_page')); ?></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-xs-6 widget-col">
                    <div class="widget payment-widget">
                        <h3><?php echo e(trans('website.pages')); ?></h3>
                        <ul>
                            <?php $__currentLoopData = $pagesFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('front.page.anyPage', $val->uuid)); ?>"><?php echo getFromJson($val->name , lang()); ?> </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div> <!-- end container -->

        <div class="lower-footer">
            <div class="container-1410">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="lower-footer-inner clearfix">
                            <div>
                                <p>ROBITSCO &copy; <?php echo e(date('Y')); ?> , All Rights Reserved</p>
                            </div>
                            <div class="social">
                                <ul class="clearfix social-links">
                                    <?php
                                        $facebook = \App\Provider::getByName('facebook');
                                        $twitter = \App\Provider::getByName('twitter');
                                        $instagram = \App\Provider::getByName('instagram');
                                        $pinterest = \App\Provider::getByName('pinterest');
                                    ?>
                                    <?php if($facebook && isset($facebook->social[0]->link)): ?>
                                        <li><a target="_blank" href="<?php echo e($facebook->social[0]->link); ?>"><i
                                                    class="ti-facebook"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($twitter && isset($twitter->social[0]->link)): ?>
                                        <li><a target="_blank" href="<?php echo e($twitter->social[0]->link); ?>"><i
                                                    class="ti-twitter-alt"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($instagram && isset($instagram->social[0]->link)): ?>
                                        <li><a target="_blank" href="<?php echo e($instagram->social[0]->link); ?>"><i
                                                    class="ti-instagram"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($pinterest && isset($pinterest->social[0]->link)): ?>
                                        <li><a target="_blank" href="<?php echo e($pinterest->social[0]->link); ?>"><i
                                                    class="ti-pinterest"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <div class="extra-link">
                                <ul>
                                    <?php if($privacyPage): ?>
                                        <li>
                                            <a href="<?php echo e(route('front.page.privacyPage')); ?>"><?php echo e(trans('website.privacy_page')); ?> </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($termsPage): ?>
                                        <li>
                                            <a href="<?php echo e(route('front.page.termsPage')); ?>"><?php echo e(trans('website.terms_page')); ?></a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- end site-footer -->

</div>
<!-- end of page-wrapper -->


<!-- All JavaScript files
================================================== -->
<script src="<?php echo e(url('assets/front/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/front/assets/js/bootstrap.min.js')); ?>"></script>

<!-- Plugins for this template -->
<script src="<?php echo e(url('assets/front/assets/js/jquery-plugin-collection.js')); ?>"></script>

<!-- Custom script for this template -->
<script src="<?php echo e(url('assets/front/assets/js/script.js')); ?>"></script>

<script>
    $('body').on('click', '.alert-close', function () {
        $(this).parents('.alert-div').hide(500, function () {
            $(this).remove();
        });
    });
</script>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
