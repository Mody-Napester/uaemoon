<form method="post" action="<?php echo e(route('permissions.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <div class="form-group">
        <label><?php echo e(trans('data_entry_screens.Name')); ?></label>
        <input type="text" name="name" class="form-control" required placeholder="Name"/>
    </div>

    <div class="form-group">
        <label><?php echo e(trans('data_entry_screens.User_Actions')); ?>

            <span data-select2-target="permission_groups_create" class="select-all text-success btn-link">(<?php echo e(trans('data_entry_screens.Select_All')); ?>)</span>
            <span data-select2-target="permission_groups_create" class="de-select-all text-success btn-link">(<?php echo e(trans('data_entry_screens.Deselect_All')); ?>)</span>
        </label>
        <select name="permission_groups[]" id="permission_groups_create" class="select2 select2-multiple" multiple="" data-placeholder="Choose ..." tabindex="-1" aria-hidden="true" required>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($group->uuid); ?>"><?php echo e($group->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group m-b-0">
        <div>
            <button type="submit" class="btn btn-primary waves-effect waves-light">
                <?php echo e(trans('data_entry_screens.Submit')); ?>

            </button>
        </div>
    </div>
</form>
