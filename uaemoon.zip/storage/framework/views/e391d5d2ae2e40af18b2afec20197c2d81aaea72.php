<form method="post" action="<?php echo e(route('roles.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <div class="row">
        <div class="col-md-8">
            <div class="form-group">
                <label><?php echo e(trans('users_groups.Users_Group_name')); ?></label>
                <input type="text" name="name" class="form-control" required placeholder="<?php echo e(trans('users_groups.Users_Group_name')); ?>"/>
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <label><?php echo e(trans('users_groups.Class')); ?></label>







                <?php $__currentLoopData = App\Enums\LabelClasses::$classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="class<?php echo e($key); ?>" style="display: block">
                        <input type="radio" name="class" id="class<?php echo e($key); ?>" value="<?php echo e($class); ?>">
                        <div class="label <?php echo e($class); ?>"><?php echo e(str_well($class)); ?></div>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($errors->has('class')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('class')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo e(trans('users_groups.Permissions')); ?>

                    <span data-select2-target="permissions-groups_create" class="select-all text-success btn-link">(<?php echo e(trans('users_groups.Select_All')); ?>)</span>
                    <span data-select2-target="permissions-groups_create" class="de-select-all text-success btn-link">(<?php echo e(trans('users_groups.Deselect_All')); ?>)</span>
                </label>
                <?php if($errors->has('permissions-groups')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('permissions-groups')); ?></strong>
            </span>
                <?php endif; ?>

                <div style="border:1px solid #dddddd;padding: 10px;border-radius: 5px;">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-primary mb-2"><?php echo e(str_well($permission->name)); ?></div>
                        <div class="row mb-2">
                            <?php $__currentLoopData = $permission->permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 all-checkbox">
                                    <label for="<?php echo e($permission_group->uuid); ?>.<?php echo e($permission->uuid); ?>">
                                        <input type="checkbox" name="permissions-groups[]"
                                               id="<?php echo e($permission_group->uuid); ?>.<?php echo e($permission->uuid); ?>"
                                               value="<?php echo e($permission_group->uuid); ?>.<?php echo e($permission->uuid); ?>">
                                        <?php echo e(str_well($permission_group->name)); ?> <?php echo e(str_well($permission->name)); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


                
                
                
                
                
                
                



            </div>
        </div>













        
            
                
                
                
                    
                        
                    
                
            
        


    </div>

    <div class="form-group m-b-0">
        <div>
            <button type="submit" class="btn btn-primary waves-effect waves-light">
                <?php echo e(trans('users_groups.Submit')); ?>

            </button>
        </div>
    </div>
</form>
