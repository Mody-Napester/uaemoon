<form method="post" action="<?php echo e(route('permissions.update', $resource->uuid)); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <div class="form-group">
        <label><?php echo e(trans('data_entry_screens.Name')); ?></label>
        <input type="text" name="name" class="form-control" required placeholder="Name" value="<?php echo e($resource->name); ?>"/>
    </div>

    <div class="form-group">
        <label><?php echo e(trans('data_entry_screens.User_Actions')); ?>

            <span data-select2-target="permission_groups_update" class="select-all text-success btn-link">(<?php echo e(trans('data_entry_screens.Select_All')); ?>)</span>
            <span data-select2-target="permission_groups_update" class="de-select-all text-success btn-link">(<?php echo e(trans('data_entry_screens.Deselect_All')); ?>)</span>
        </label>
        <select name="permission_groups[]" id="permission_groups_update" class="select2 select2-multiple" multiple="" data-placeholder="Choose ..." tabindex="-1" aria-hidden="true" required>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(in_array($group->id, $resource->permission_groups->pluck('id')->toArray() )): ?> selected <?php endif; ?> value="<?php echo e($group->uuid); ?>"><?php echo e($group->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group m-b-0">
        <div>
            <button type="submit" class="btn btn-success waves-effect waves-light">
                <?php echo e(trans('data_entry_screens.Update')); ?>

            </button>
        </div>
    </div>
</form>
