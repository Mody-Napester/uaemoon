<?php $__env->startSection('content'); ?>
    <!-- start of hero -->
    <section class="hero-slider hero-style-1">
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image"
                             data-background="<?php echo e(asset('public/images/slider/' . $val->image)); ?>">
                            <div class="container-1410">
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                        </div> <!-- end slide-inner -->
                    </div> <!-- end swiper-slide -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- end swiper-wrapper -->

            <!-- Control -->
            <div class="control-slider swiper-control">
                <div></div>
                <div class="swiper-pagination"></div>
                <div>
                    <div class="swiper-button-next">
                        <svg class="slider-nav slider-nav-progress" viewBox="0 0 46 46">
                            <g class="slider-nav-path-progress-color">
                                <path d="M0.5,23a22.5,22.5 0 1,0 45,0a22.5,22.5 0 1,0 -45,0"/>
                            </g>
                        </svg>
                        <svg class="slider-nav slider-nav-transparent sw-ar-rt" viewBox="0 0 46 46">
                            <circle class="slider-nav-path" cx="23" cy="23" r="22.5"/>
                        </svg>
                    </div>
                    <div class="swiper-button-prev">
                        <svg class="slider-nav slider-nav-transparent sw-ar-lf" viewBox="0 0 46 46">
                            <circle class="slider-nav-path" cx="23" cy="23" r="22.5"/>
                        </svg>
                    </div>
                </div>
            </div>
            <!-- /Control -->
        </div>
    </section>
    <!-- end of hero slider -->

    <!-- start trendy-product-section -->
    <section class="trendy-product-section section-padding" style="padding: 80px 0 0 0;">
        <div class="container-1410">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="section-title-s2">
                        <h2><?php echo e(trans('website.featured_ads')); ?></h2>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col col-xs-12">
                    <div class="products-wrapper">
                        <ul class="products product-row-slider">
                            <?php $__currentLoopData = $featured_adv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="product">
                                <div class="product-holder">

                                    <a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>">
                                        <img loading=lazy src="<?php echo e(url($val->cover)); ?>"
                                             alt style="width: 275px;height: 340px;"></a>
                                    <div class="shop-action-wrap">
                                        <ul class="shop-action">
                                            <li>
                                                <a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>" title="<?php echo e(trans('website.view')); ?>"><i
                                                        class="fi flaticon-view"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product-info">
                                    <h4><a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>"><?php echo e(lang() == 'ar' ? $val->title_ar : $val->title_en); ?></a></h4>
                                    <span class="woocommerce-Price-amount amount">
                                        <ins>
                                            <span class="woocommerce-Price-amount amount">
                                                <bdi><?php echo getFromJson($val->category->name , lang()); ?></bdi>
                                            </span>
                                        </ins>

                                    </span>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div> <!-- end container-1410 -->
    </section>
    <!-- end trendy-product-section -->

    <!-- start featured-proeducts-section-s2 -->
    <section class="featured-proeducts-section-s2 section-padding">
        <div class="container-1410">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="section-title-s2">
                        <h2><?php echo e(trans('website.all_categories')); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col col-xs-12">
                    <?php
                        $chunks = array_chunk($categories->toArray(), 3);
                    ?>
                    <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-grids clearfix">
                            <?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $val2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="<?php echo e(route('front.category.show', $val2['uuid'])); ?>"><img loading="lazy" style="width: 275px;height: 340px;"
                                                         src="<?php echo e(url('public/images/category/picture/'. $val2['picture'])); ?>"
                                                         alt></a>
                                    </div>
                                    <div class="details" style="padding: 15px;">
                                        <h3><?php echo e(getFromJson($val2['name'] , lang())); ?></h3>
                                        <a href="<?php echo e(route('front.category.show', $val2['uuid'])); ?>" class="shop-btn"><?php echo e(trans('website.see_more')); ?></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div> <!-- end container-1410 -->
    </section>
    <!-- end featured-proeducts-section-s2 -->

    <!-- start trendy-product-section -->
    <section class="trendy-product-section section-padding" style="padding: 80px 0 80px 0;">
        <div class="container-1410">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="section-title-s2">
                        <h2><?php echo e(trans('website.random_ads')); ?></h2>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col col-xs-12">
                    <div class="products-wrapper">
                        <ul class="products product-row-slider">
                            <?php $__currentLoopData = $random_adv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="product">
                                    <div class="product-holder">
                                        
                                        <a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>">
                                            <img loading=lazy src="<?php echo e(url($val->cover)); ?>"
                                                 alt style="width: 275px;height: 340px;"></a>
                                        <div class="shop-action-wrap">
                                            <ul class="shop-action">
                                                <li>
                                                    <a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>" title="<?php echo e(trans('website.view')); ?>"><i
                                                            class="fi flaticon-view"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <h4><a href="<?php echo e(route('front.advertise.show', $val->uuid)); ?>"><?php echo e(lang() == 'ar' ? $val->title_ar : $val->title_en); ?></a></h4>
                                        <span class="woocommerce-Price-amount amount">
                                        <ins>
                                            <span class="woocommerce-Price-amount amount">
                                                <bdi><?php echo getFromJson($val->category->name , lang()); ?></bdi>
                                            </span>
                                        </ins>

                                    </span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div> <!-- end container-1410 -->
    </section>
    <!-- end trendy-product-section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>