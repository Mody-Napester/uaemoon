<?php $__env->startSection('title'); ?>
    SEO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('settings.page_seo')); ?></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo e(Form::open(array('files' => true, 'route' => 'updateSettings'))); ?>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label><?php echo e(trans('settings.page_seo_title_ar')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_title_ar']); ?>" name="home_seo_title_ar"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-6">
                        <label><?php echo e(trans('settings.page_seo_title_en')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_title_en']); ?>" name="home_seo_title_en"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-12">
                        <label><?php echo e(trans('settings.meta_keywords_ar_with_comma_separated')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_keywords_ar']); ?>"
                               name="home_seo_keywords_ar"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-12">
                        <label><?php echo e(trans('settings.meta_keywords_en_with_comma_separated')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_keywords_en']); ?>"
                               name="home_seo_keywords_en"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-12">
                        <label><?php echo e(trans('settings.meta_description_ar')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_desc_ar']); ?>" name="home_seo_desc_ar"
                               class="form-control">
                    </div>

                    <div class="form-group col-md-12">
                        <label><?php echo e(trans('settings.meta_description_en')); ?></label>
                        <input type="text" value="<?php echo e($settings['home_seo_desc_en']); ?>" name="home_seo_desc_en"
                               class="form-control">
                    </div>
                </div>
                <div class="form-group col-md-12">
                    <button class="btn btn-sm btn-info" type="submit"><?php echo e(trans('settings.save')); ?></button>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>