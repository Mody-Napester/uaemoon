<?php $__env->startSection('title'); ?> <?php echo e(trans('slider.slider')); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {

            $(".ask-me").click(function (e) {
                e.preventDefault();
                if (confirm('Are You Sure?')) {
                    window.location.replace($(this).attr('href'));
                }
            });
            $(".editImageOrder").change(function (e) {
                var ref_id = $(this).attr('ref_id')
                var order = $(this).val()
                if (ref_id) {
                    $.ajax({
                        url: '<?php echo e(route('updatedSliderOrder')); ?>',
                        method: 'POST',
                        data: {
                            ref_id: ref_id,
                            order: order
                        },
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        success: function (data) {
                            if (data) {
                                addAlert('success', 'Updated Successfully, Order #' + order, 0);
                            }
                        }
                    });
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="btn-group pull-right m-t-15">
                <?php if(check_authority('create.slider')): ?>
                    <a href="<?php echo e(route('addSlider')); ?>" class="btn btn-default waves-effect waves-light"><i
                            class="fa fa-plus"></i> <?php echo e(trans('slider.add_new')); ?></a>
                <?php endif; ?>
            </div>

            <h4 class="page-title"><?php echo e(trans('slider.slider')); ?> (<?php echo e($resources->count()); ?>)</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('slider.slider')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('slider.list')); ?></li>
            </ol>

        </div>
    </div>
    <!-- Main page content-->
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <div class="container-fluid">
                    <h4 class="m-t-0 header-title"><?php echo e(trans('slider.list_of_pages')); ?></h4>
                </div>
                <table data-page-length='50' class="table table-responsive table-bordered table-sm" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(trans('slider.image')); ?></th>
                        <th><?php echo e(trans('slider.order')); ?></th>
                        <th><?php echo e(trans('slider.actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($val['id']); ?></td>
                            <td><img src="<?php echo e(asset('public/images/slider/' . $val['image'])); ?>" height="100" width="300"></td>
                            <td>
                                <input autocomplete="off" type="number" style="width: 50px;" class="editImageOrder"
                                       value="<?php echo e($val['order']); ?>" ref_id="<?php echo e($val['uuid']); ?>">
                            </td>
                            <td>
                                <?php if(check_authority('edit.slider')): ?>
                                    <a href="<?php echo e(route('editSlider' , [$val->uuid])); ?>"
                                       class="badge badge-sm badge-success mr-2"><i class="fa fa-edit"></i></a>
                                <?php endif; ?>
                                <?php if(check_authority('delete.slider')): ?>
                                    <a href="<?php echo e(route('deleteSlider' , [$val->uuid])); ?>"
                                       class="badge badge-sm badge-danger ask-me"><i class="fa fa-times"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>