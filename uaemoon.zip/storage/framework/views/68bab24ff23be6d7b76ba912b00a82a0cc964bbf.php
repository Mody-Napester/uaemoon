<?php $__env->startSection('title'); ?> <?php echo e(trans('advertise.advertises')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title"><?php echo e(trans('advertise.advertises')); ?> (<?php echo e($resources->count()); ?>)</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('advertise.advertises')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('advertise.list')); ?></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <div class="container-fluid">
                    <h4 class="m-t-0 header-title"><?php echo e(trans('advertise.List_Of_advertises')); ?></h4>
                </div>

                <table data-page-length='50' id="datatable-users-buttons"
                       class="table table-responsive table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Category</th>
                        <th>Title</th>
                        <th>Cover</th>
                        <th>Status</th>
                        <th>Status At</th>
                        <th>Is VIP</th>

                        <th>Created By</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e(isset($resource->category->name) ? getFromJson($resource->category->name , lang()) : '-'); ?></td>
                            <td><?php echo e(lang() == 'ar' ? $resource->title_ar : $resource->title_en); ?></td>
                            <td>
                                <div style="width:50px;height: 50px;overflow: hidden">
                                    <img style="width:100%;" src="<?php echo e(url($resource->cover)); ?>" alt="">
                                </div>
                            </td>
                            <td>
                                <?php if($resource->status == 0): ?>
                                    <span class="badge badge-warning badge-pill">Pending</span>
                                <?php elseif($resource->status == 1): ?>
                                    <span class="badge badge-success badge-pill">Approved</span>
                                <?php elseif($resource->status == 2): ?>
                                    <span class="badge badge-danger badge-pill">Not Approved</span>
                                <?php elseif($resource->status == 3): ?>
                                    <span class="badge badge-dark badge-pill">Expired</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($resource->status == 0): ?>
                                    <span
                                        class="badge badge-warning badge-pill">Created At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->created_at))); ?></span>
                                <?php elseif($resource->status == 1): ?>
                                    <span
                                        class="badge badge-success badge-pill">Approved At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->approved_at))); ?></span>
                                <?php elseif($resource->status == 2): ?>
                                    <span
                                        class="badge badge-danger badge-pill">Not Approved At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->not_approved_at))); ?></span>
                                <?php elseif($resource->status == 3): ?>
                                    <span
                                        class="badge badge-dark badge-pill">Expired At: <?php echo e(date('Y-m-d h:i A', strtotime($resource->expired_at))); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($resource->is_featured == 0): ?>
                                    <span class="badge badge-warning badge-pill">NO</span>
                                <?php elseif($resource->is_featured == 1): ?>
                                    <span class="badge badge-success badge-pill">YES</span>
                                <?php endif; ?>
                            </td>



                            <td>
                                <?php echo e(isset($resource->created_by_user->name) ? $resource->created_by_user->name : '-'); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('advertise.show' , $resource->uuid)); ?>"
                                   class="badge badge-sm badge-info mr-2" title="<?php echo e(trans('advertise.show')); ?>"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($resources->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var tableDTUsers = $('#datatable-users-buttons').DataTable({
            lengthChange: false,
            ordering: false,
            buttons: [
                {
                    extend: 'copyHtml5',
                    exportOptions: {
                        columns: [0, 1, 2, 4, 5, 6, 7]
                    }
                },
                {
                    extend: 'excelHtml5',
                    exportOptions: {
                        columns: [0, 1, 2, 4, 5, 6, 7]
                    }
                },
                {
                    extend: 'pdfHtml5',
                    exportOptions: {
                        columns: [0, 1, 2, 4, 5, 6, 7]
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: [0, 1, 2, 4, 5, 6, 7]
                    }
                }
            ],
        });
        tableDTUsers.buttons().container().appendTo('#datatable-users-buttons_wrapper .col-md-6:eq(0)');

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>