<?php $__env->startSection('title'); ?> <?php echo e(trans('data_entry_screens.Data_Entry_Screens')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">

            <h4 class="page-title"><?php echo e(trans('data_entry_screens.Data_Entry_Screens')); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo e(config('app.name')); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(trans('data_entry_screens.Data_Entry_Screens')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e(trans('data_entry_screens.Index')); ?></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box ">
                <h4 class="m-t-0 header-title"><?php echo e(trans('data_entry_screens.All_Data_Entry_Screens')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    <?php echo e(trans('data_entry_screens.Here_you_will_find_all_the_resources_to_make_actions_on_them')); ?>.
                </p>

                <table id="datatable" class="table table-responsive table-striped table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th><?php echo e(trans('data_entry_screens.Id')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Name')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Groups')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Created_by')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Updated_by')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Created_at')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Updated_at')); ?></th>
                        <th><?php echo e(trans('data_entry_screens.Control')); ?></th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($resource->id); ?></td>
                            <td><?php echo e($resource->name); ?></td>
                            <td>
                                <?php $__currentLoopData = $resource->permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="label label-default"><?php echo e($permission_group->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($resource->createdBy->name); ?></td>
                            <td><?php echo e($resource->updatedBy->name); ?></td>
                            <td><?php echo e($resource->created_at); ?></td>
                            <td><?php echo e($resource->updated_at); ?></td>
                            <td>






                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- end row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <!-- Create new -->
                <h4 class="m-t-0 header-title">Create new <?php echo e(trans('data_entry_screens.Data_Entry_Screens')); ?></h4>
                <p class="text-muted font-14 m-b-30">
                    <?php echo e(trans('data_entry_screens.Create_new_resource_from_here')); ?>.
                </p>

                <?php echo $__env->make('permissions.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <!-- end card-box -->
        </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>