<form method="post" action="<?php echo e(route('permission-groups.update', $resource->uuid)); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" required placeholder="Name" value="<?php echo e($resource->name); ?>"/>
    </div>

    <div class="form-group m-b-0">
        <div>
            <button type="submit" class="btn btn-success waves-effect waves-light">
                Submit
            </button>
        </div>
    </div>
</form>