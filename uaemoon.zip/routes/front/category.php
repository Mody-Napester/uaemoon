<?php

Route::get('categories/show/{uuid}', 'Front\CategoryController@show')->name('front.category.show');
