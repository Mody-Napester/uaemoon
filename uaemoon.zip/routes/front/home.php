<?php

Route::get('/', 'Front\HomeController@index')->name('front.home.index');
