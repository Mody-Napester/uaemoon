<?php

return array (
  'Name' => 'الاسم',
  'User_Actions' => 'عمليات المستخدم',
  'Select_All' => 'تحديد الكل',
  'Deselect_All' => 'الغاء تحديد الكل',
  'Submit' => 'ارسال',
  'Update' => 'تحديث',
  'Data_Entry_Screens' => 'شاشات إدخال البيانات',
  'Index' => 'قائمة',
  'Create_new_resource_from_here' => 'إنشاء مورد جديد من هنا',
  'All_Data_Entry_Screens' => 'جميع شاشات إدخال البيانات',
  'Here_you_will_find_all_the_resources_to_make_actions_on_them' => 'ستجد هنا جميع الموارد اللازمة لاتخاذ إجراءات بشأنها',
  'Id' => 'التعريف',
  'Groups' => 'مجموعات',
  'Created_by' => 'انشأ بواسطة',
  'Updated_by' => 'تحديث بواسطة',
  'Created_at' => 'أنشئت في',
  'Updated_at' => 'تم التحديث فى',
  'Control' => 'يتحكم',
);
