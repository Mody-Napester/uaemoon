<?php

return array (
  'Customers' => 'العملاء',
  'Data_Entry_Screens' => 'شاشات الادخال',
  'Form_Inputs' => 'حقول النموذج',
  'Forms' => 'النماذج',
  'List_Answers' => 'الردود',
  'Lookups' => 'نماذج برمجية',
  'Permission_Control_System' => 'التحكم في الأذونات',
  'Security' => 'الحماية',
  'Settings' => 'الإعدادات',
  'Support_Form' => 'نموذج الدعم',
  'Translations' => 'الترجمة',
  'User_Actions' => 'العمليات',
  'Users' => 'المستخدمين',
  'Users_Groups' => 'مجموعات المستخدمين',
  'Resources' => 'الموارد الرئيسية',
);
