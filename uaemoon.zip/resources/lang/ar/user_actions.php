<?php

return array (
  'User_Actions' => 'عمليات المستخدم',
);
