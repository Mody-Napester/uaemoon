<?php

return array (
  'Customers' => 'العملاء',
  'Dashboard' => 'لوحة التحكم',
  'Data_Entry_Screens' => 'شاشات إدخال البيانات',
  'Logout' => 'تسجيل خروج',
  'Profile' => 'الملف الشخصي',
  'Support_Problems' => 'مشاكل الدعم',
  'User_Actions' => 'إجراءات المستخدم',
  'Users' => 'المستخدمون',
  'Users_Groups' => 'مجموعات المستخدمين',
);
