<?php

return array (
  'Name' => 'Name',
  'User_Actions' => 'User Actions',
  'Select_All' => 'Select All',
  'Deselect_All' => 'Deselect All',
  'Submit' => 'Submit',
  'Update' => 'Update',
  'Data_Entry_Screens' => 'Data Entry Screens',
  'Index' => 'Index',
  'Create_new_resource_from_here' => 'Create new resource from here',
  'All_Data_Entry_Screens' => 'All Data Entry Screens',
  'Here_you_will_find_all_the_resources_to_make_actions_on_them' => 'Here you will find all the resources to make actions on them',
  'Id' => 'Id',
  'Groups' => 'Groups',
  'Created_by' => 'Created by',
  'Updated_by' => 'Updated by',
  'Created_at' => 'Created at',
  'Updated_at' => 'Updated at',
  'Control' => 'Control',
);
