<?php

return array (
  'Dashboard' => 'Dashboard',
  'User_Actions' => 'User Actions',
  'Data_Entry_Screens' => 'Data Entry Screens',
  'Users_Groups' => 'Users Groups',
  'Users' => 'Users',
  'Customers' => 'Customers',
  'Support_Problems' => 'Support Problems',
  'Profile' => 'Profile',
  'Logout' => 'Logout',
);
